from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

donors = []
emergency_requests = []

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        donor = {
            'name': request.form.get('name'),
            'blood_group': request.form.get('blood_group'),
            'city': request.form.get('city'),
            'phone': request.form.get('phone'),
            'donor_type': request.form.get('donor_type')
        }
        donors.append(donor)
        return redirect(url_for('search'))
    return render_template('register.html')

@app.route('/search', methods=['GET', 'POST'])
def search():
    results = []
    searched = False
    if request.method == 'POST':
        searched = True
        blood_group = request.form.get('blood_group')
        city = request.form.get('city', '').lower()
        results = [d for d in donors if d['blood_group'] == blood_group and city in d['city'].lower()]
    return render_template('search.html', results=results, searched=searched)

@app.route('/emergency', methods=['GET', 'POST'])
def emergency():
    message = None
    if request.method == 'POST':
        req = {
            'patient_name': request.form.get('patient_name'),
            'urgency': request.form.get('urgency'),
            'request_type': request.form.get('request_type'),
            'blood_group': request.form.get('blood_group'),
            'city': request.form.get('city'),
            'hospital': request.form.get('hospital'),
            'phone': request.form.get('phone'),
            'notes': request.form.get('notes')
        }
        emergency_requests.append(req)
        message = 'Emergency request posted successfully!'
    return render_template('emergency.html', message=message)

@app.route('/contact')
def contact():
    return render_template('contact.html')

if __name__ == '__main__':
    app.run(debug=True)
